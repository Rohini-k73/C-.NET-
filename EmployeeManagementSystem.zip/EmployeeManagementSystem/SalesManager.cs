﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeManagementSystem
{

    class SalesManager : Employee //inherit
    {
        public double Commission { get; set; } // Commission per sale
        public int Sales { get; set; } // No of sales 

        // Constructor
        public SalesManager(int employeeID, string name, string location, double baseSalary, double commission, int sales)
            : base(employeeID, name, location, baseSalary)
        {
            this.Commission = commission;
            this.Sales = sales;
        }

        // Base Salary + Commission per sale
        public override double CalculateSalary()
        {
            return BaseSalary + (Sales * Commission);
        }

      
        public override void DisplayDetails()
        {
            base.DisplayDetails();
            Console.WriteLine($"Role: Sales Manager");
            Console.WriteLine($"Sales: {Sales}");
            Console.WriteLine($"Commission per Sale: {Commission}");
            Console.WriteLine($"Total Salary: {CalculateSalary()}");
        }
    }
}

