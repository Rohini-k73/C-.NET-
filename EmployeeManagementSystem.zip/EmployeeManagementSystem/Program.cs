﻿using System;

namespace EmployeeManagementSystem
{
    class Program
    {
        public static void Main()
        {
            EmployeeManager manager = new EmployeeManager();

            int choice;
            Console.WriteLine("\n ........Employee Management System.........");
            do
            {
                Console.WriteLine("\n1. Add Employee (Sales Manager / HR)");
                Console.WriteLine("2. Display Employees");
                Console.WriteLine("3. Search Employee by ID");
                Console.WriteLine("4. Remove Employee");
                Console.WriteLine("5. Exit");
                Console.Write("Enter choice: ");

                if (!int.TryParse(Console.ReadLine(), out choice))
                {
                    Console.WriteLine("Invalid input! Please enter a valid number.");
                    continue;
                }

                switch (choice)
                {
                    case 1:
                        manager.AddEmployee();
                        break;

                    case 2:
                        manager.DisplayEmployees();
                        break;
                    case 3:
                        manager.SearchEmployeeById(); 
                        break;

                    case 4:
                        RemoveEmployee(manager);
                        break;
                    case 5:
                        Console.WriteLine("...Exiting...");
                        Console.WriteLine("....Thank you!....");
                        break;

                    default:
                        Console.WriteLine("Invalid choice! Try again.");
                        break;
                }

                if (choice != 5)
                {
                    Console.Write("\n Do you want to continue? (Y/N): ");
                    string response = Console.ReadLine().ToLower();
                    if (response != "y")
                    {
                        Console.WriteLine("...Exiting...");
                        Console.WriteLine("....Thank you!....");
                        break;
                    }
                }

            } while (choice != 5);
        }

       
        private static void RemoveEmployee(EmployeeManager manager)
        {
            Console.Write("\nEnter Employee ID to Remove: ");
            if (!int.TryParse(Console.ReadLine(), out int empID))
            {
                Console.WriteLine("Invalid Employee ID!");
                return;
            }

            manager.RemoveEmployee(empID);
        }

    }
}
