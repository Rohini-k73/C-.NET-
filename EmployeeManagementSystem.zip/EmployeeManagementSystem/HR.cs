﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeManagementSystem
{
    class HR : Employee
    {
        public int EmployeesHired { get; set; } // Number of employees hired
        private const double HiringBonus = 1000; // Bonus per hire

      
        public HR(int employeeID, string name, string location, double baseSalary, int employeesHired)
            : base(employeeID, name, location, baseSalary)
        {
            this.EmployeesHired = employeesHired;
        }
    
        public override double CalculateSalary()
        {
            return BaseSalary + (EmployeesHired * HiringBonus);// Base Salary + Hiring Bonus
        }

     
        public override void DisplayDetails()
        {
            base.DisplayDetails();
            Console.WriteLine($"Role: HR");
            Console.WriteLine($"Employees Hired: {EmployeesHired}");
            Console.WriteLine($"Hiring Bonus per Employee: {HiringBonus}");
            Console.WriteLine($"Total Salary: {CalculateSalary()}");
        }
    }
}

