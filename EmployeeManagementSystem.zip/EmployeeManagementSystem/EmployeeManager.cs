﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Win32;

namespace EmployeeManagementSystem
{
    class EmployeeManager : IEmployeeOperations
    {
        private List<Employee> employees = new List<Employee>(); // Employees list


        //public void AddEmployee(Employee emp)
        //{
        //    employees.Add(emp);
        //    Console.WriteLine(" Employee added successfully!");
        //}


        public void AddEmployee()
        {
            Console.Write("\nEnter Employee ID: ");
            if (!int.TryParse(Console.ReadLine(), out int empID))
            {
                Console.WriteLine("Invalid Employee ID!");
                return;
            }

            Console.Write("Enter Name: ");
            string name = Console.ReadLine();

            Console.Write("Enter Location: ");
            string location = Console.ReadLine();

            Console.WriteLine("\nSelect Employee Type:");
            Console.WriteLine("1. Sales Manager");
            Console.WriteLine("2. HR");
            Console.Write("Enter choice (1/2): ");

            if (!int.TryParse(Console.ReadLine(), out int choice))
            {
                Console.WriteLine("Invalid input! Please enter 1 for Sales Manager or 2 for HR.");
                return;
            }

            if (choice == 1) // Sales Manager
            {
                Console.Write("Enter Base Salary: ");
                if (!double.TryParse(Console.ReadLine(), out double baseSalary))
                {
                    Console.WriteLine("Invalid salary input!");
                    return;
                }

                Console.Write("Enter Sales: ");
                if (!int.TryParse(Console.ReadLine(), out int sales))
                {
                    Console.WriteLine("Invalid sales input!");
                    return;
                }

                Console.Write("Enter Commission per Sale: ");
                if (!double.TryParse(Console.ReadLine(), out double commission))
                {
                    Console.WriteLine("Invalid commission input!");
                    return;
                }

                SalesManager sm = new SalesManager(empID, name, location, baseSalary, commission, sales);
                employees.Add(sm);
                Console.WriteLine("Sales Manager added successfully!");
            }
            else if (choice == 2) // HR
            {
                Console.Write("Enter Monthly Salary: ");
                if (!double.TryParse(Console.ReadLine(), out double monthlySalary))
                {
                    Console.WriteLine("Invalid salary input!");
                    return;
                }

                Console.Write("Enter Employees Hired: ");
                if (!int.TryParse(Console.ReadLine(), out int employeesHired))
                {
                    Console.WriteLine("Invalid input!");
                    return;
                }

                HR hr = new HR(empID, name, location, monthlySalary, employeesHired);
                employees.Add(hr);
                Console.WriteLine("HR added successfully!");
            }
            else
            {
                Console.WriteLine("Invalid choice! Please enter 1 for Sales Manager or 2 for HR.");
            }
        }


        // Remove Employee by ID
        public void RemoveEmployee(int empID)
        {
            Employee employeeToRemove = employees.FirstOrDefault(emp => emp.EmployeeID == empID);

            if (employeeToRemove != null)
            {
                employees.Remove(employeeToRemove);
                Console.WriteLine($"Employee with ID {empID} removed successfully!");
            }
            else
            {
                Console.WriteLine($"Employee with ID {empID} not found!");
            }
        }

        public void SearchEmployeeById()
        {
            Console.Write("Enter Employee ID to Search: ");
            if (!int.TryParse(Console.ReadLine(), out int empID))
            {
                Console.WriteLine("Invalid Employee ID!");
                return;
            }

            var employee = employees.FirstOrDefault(e => e.EmployeeID == empID);

            if (employee != null)
            {
                Console.WriteLine("\nEmployee Found:");
                employee.DisplayDetails();
                Console.WriteLine("-----------------------");
            }
            else
            {
                Console.WriteLine("No employee found with the given ID.");
            }
        }

        public void DisplayEmployees()
        {
            if (employees.Count == 0)
            {
                Console.WriteLine("No employees to display!");
                return;
            }
            //Use linq
            //var sortedEmployees = employees.OrderBy(e => e.Name); // Sort employees by name
            var sortedEmployees = employees.OrderBy(e => e.EmployeeID); // Sort employees by Employee ID


            Console.WriteLine("\n.....List of Employees.....");
            foreach (var emp in sortedEmployees)
            {
                emp.DisplayDetails();
                Console.WriteLine($"Salary: {emp.CalculateSalary()}");
                Console.WriteLine("-----------------------");
            }
        }

    }
}

