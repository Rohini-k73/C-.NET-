﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeManagementSystem
{
    abstract class Employee
    {
        // Properties
        public int EmployeeID { get; set; }
        public string Name { get; set; }
        public string Location { get; set; } 
        public double BaseSalary { get; set; } 

        // Constructor
        public Employee(int employeeID, string name, string location, double baseSalary)
        {
            this.EmployeeID = employeeID;
            this.Name = name;
            this.Location = location;
            this.BaseSalary = baseSalary;
        }

        //Abstract Method
        public abstract double CalculateSalary();

        // Virtual Method 
        public virtual void DisplayDetails()
        {
           
            Console.WriteLine($"ID: {EmployeeID}");
            Console.WriteLine($"Name: {Name}");
            Console.WriteLine($"Location: {Location}");
            Console.WriteLine($"Base Salary: {BaseSalary}");
        }

    }
}

